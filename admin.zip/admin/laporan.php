<html>
    <head>
        <title>
            Laporan Barang
        </title>
        <style>
            h1, h2, h3 {
                text-align: center;
            }
            table {
                border: 1px solid black;    
            }
            td, th {
                border: 1px solid black;
                border-collapse: collapse;
            }

            th {
                background-color: gray;
            }
        </style>
    </head>
    <body>
        <h1>Toko Yulia Furniture</h1>
        <h2>Laporan ...</h2>
        <h2>Tanggal</h2>

        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
            </tr>
        </table>


        <div style="float: right; text-align: center; width: 300px;">
            Pemilik Toko 
            <br>
            <br>
            <br>
            (................)
        </div>
    </body>
</html>